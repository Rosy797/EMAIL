package com.company;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.*;
public class Main {
    private static final String regex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
    private static final String regex1 = " ^+91[0-9]";
    public static void main(String args[]) {

                List<String> emails = new ArrayList<String>();

        List<String> emails1 = new ArrayList<String>();

        System.out.println("enter the email");
        System.out.println("enter the phoneno");
                Scanner sc = new Scanner(System.in);
                String a = sc.nextLine();
                String b =sc.next();
                emails1.add(b);
                emails.add(a);
                System.out.println(a);
        System.out.println(b);
                Pattern pattern = Pattern.compile(regex);
        Pattern pattern1 = Pattern.compile(regex1);
                for (String value : emails) {
                    Matcher matcher = pattern.matcher(value);

                    System.out.println( value  + (matcher.matches() ? "valid" : "invalid"));
                }
        for (String regex1 : emails1) {
            Matcher matcher = pattern.matcher(regex1);

            System.out.println( regex1  + (matcher.matches() ? "valid" : "invalid"));
        }


    }


        }






